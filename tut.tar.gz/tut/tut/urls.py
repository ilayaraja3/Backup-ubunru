"""tut URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin


# urlpatterns = [
#     path('admin/', admin.site.urls),
# ]
from django.urls import include, path
from django.urls import include


from rest_framework import routers
from quickstart import views
from django.conf.urls import url
from quickstart import urls
from rest_framework.documentation import include_docs_urls
from rest_framework_swagger.views import get_swagger_view
#from rest_framework_swagger.views import get_schema_view
#from rest_framework.schemas import get_schema_view
from rest_framework_swagger import renderers
from rest_framework_swagger.renderers import SwaggerUIRenderer, OpenAPIRenderer,JSONRenderer
from swagger_schema import SwaggerSchemaView
from rest_framework import permissions
from drf_yasg.views import get_schema_view
import execution
from drf_yasg import openapi
from quickstart.views import UserViewSet,ComputerSerializer,MyView,MyViewRe,MyViewRew,MyViewQuery
from quickstart.views import *
from audit.views import *
class JSONOpenAPIRenderer(renderers.OpenAPIRenderer):
   media_type = 'application/json'
schema_view = get_swagger_view(title="Swagger Docs",)
#schema_view = get_schema_view(title='Users API', renderer_classes=[OpenAPIRenderer, SwaggerUIRenderer,JSONOpenAPIRenderer,JSONRenderer])
#schema_view = get_schema_view(title='Acqueon API',renderer_classes=[SwaggerUIRenderer])
schema_view = get_schema_view(openapi.Info(title="Snippets API",
      default_version='v1',
      description="Test description",
      terms_of_service="https://www.google.com/policies/terms/",
      contact=openapi.Contact(email="contact@snippets.local"),
      license=openapi.License(name="BSD License"),
   ),
   public=True,
   permission_classes=(permissions.AllowAny,),
)
#router = routers.DefaultRouter()
#router.register(r'users', views.UserViewSet)
#router.register(r'groups', views.GroupViewSet)
#router.register(r'other', views.Uni)

# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
# urlpatterns = [
#     #path('', include(router.urls)),
#     #path('', include(urls)),
#     url(r'^', schema_view),
#     url(r'^demoSer/$', views.get_queryset),
#     url(r'^swagger/<name>$', views.save_medical),
#     url(r'^swag', views.save_medicaldata),
#     url(r'^/rest/$', views.save_me),
#     url(r'^/restFoo', views.foo_view),
#     url(r'^/docs', SwaggerSchemaView.as_view()),
#
#
#     #path('/', include(demo.urls)),
# ]
from rest_framework_swagger.views import get_swagger_view
schema_view = get_swagger_view(title='AIQ_Analytics API')
from django.urls import path
urlpatterns = [
    path('', schema_view)
]

urlpatterns += [
    #url(r'^', schema_view),
    #url(r'^docs/', include('rest_framework_swagger.urls')),
    #url(r'^AIQ_Analytics/p2p/modelParameters/demoSer/(?P<name>.+)/(?P<no>.+)/$', views.get_queryset),
    #----------------------------Admin Model---------------------------------------
    url(r'^AIQ_Analytics/model/p2p/admin/list', getmodelList),
    url(r'^AIQ_Analytics/model/p2p/admin/parameters/add', myModelData.as_view()),
    url(r'^AIQ_Analytics/model/p2p/admin/parameters/update', myModelDataUpdate.as_view()),
    url(r'^AIQ_Analytics/model/p2p/admin/parameters/list?page=1&count=10', getparamList),
    url(r'^AIQ_Analytics/model/p2p/admin/oozieJobs/list?page=1&count=10',getOosiJobsList),
    url(r'^AIQ_Analytics/model/p2p/admin?tableName=tab1&action=start&type=ondemand', modelSchedule),
    url(r'^AIQ_Analytics/model/p2p/admin/availableModels/list?page=1&count=10', availableModels),
    url(r'^AIQ_Analytics/model/p2p/admin/getFeatures?page=1&count=10', getFeature),
    url(r'^AIQ_Analytics/model/p2p/admin/updateFeatures', updateFeature.as_view()),
    url(r'^AIQ_Analytics/model/p2p/admin/rules/list?page=1&count=10',getRulesList),
    url(r'^AIQ_Analytics/model/p2p/admin/purge?count=100',modelPurge),
    url(r'^AIQ_Analytics/model/p2p/admin/customer/create', customerAdd.as_view()),
    url(r'^AIQ_Analytics/model/p2p/admin/customer/update',customerUpdate.as_view()),
    url(r'^AIQ_Analytics/model/p2p/admin/customer/delete', customerDelete),
    #---------Audit-------------------------------------------------------------
    #url(r'^Audit/', include('audit.urls')),
    url(r'^AIQ_Analytics/model/p2p/ingestionStatus/list?type=ondemand&page=1&count=10',auditIngestionStatus),
    url(r'^AIQ_Analytics/model/p2p/audit/predictionStatus/list?page=1&count=10',auditPredictionStatus),
    url(r'^AIQ_Analytics/model/p2p/audit/models/list?page=1&count=10', auditModelList),
    url(r'^AIQ_Analytics/admin/audit/customers/list?page=1&count=10', auditCustomerList),
    #-------------Execution API--------------------------------------------------
    #url(r'^Execution/', include('execution.urls')),
    url(r'^AIQ_Analytics/model/p2p/run/batch',runBatchExecution.as_view()),
    url(r'^AIQ_Analytics/model/p2p/run/status/?jobId=12', executionJobStatus),
    url(r'^AIQ_Analytics/model/p2p/run/interruptJob/?jobId=12', intruptJob),
    url(r'^AIQ_Analytics/model/p2p/run/single',runSingleExecution.as_view()),

    #--------------------------------------------------------------------------------------
    #url(r'^AIQ_Analytics/execution/', include('execution.urls')),
    #url(r'^admin/', include('adminapi.urls')),
    #url(r'^audit/', include('audit.urls')),
    #url(r'^audit/', include('audit.urls')),
    #url(r'^testex', MyViewRe.as_view()),
    #url(r'^quryL/(?P<name>%s)/?$', views.get_querysetRList),
    #url(r'^users/', include('quickstart.urls')),
    #url(r'^testTest', MyViewRew.post({'post':'post'})),
]


