#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

# Create your views here.
from django.contrib.auth.models import User, Group
from rest_framework import viewsets
from quickstart.serializers import UserSerializer, GroupSerializer,UniSerializer
from rest_framework.validators import ValidationError

from quickstart.models import University
from rest_framework.decorators import api_view
from rest_framework_swagger import renderers
from rest_framework.decorators import api_view, renderer_classes
from django.core.serializers import serialize
from .models import *
from rest_framework import status
from django.http import JsonResponse
from rest_framework import viewsets
import logging
import threading
import time
import os
from django.conf import settings
from django.http import HttpResponse, Http404
from rest_framework.response import Response
import json
from rest_framework.filters import BaseFilterBackend
import coreapi
from rest_framework.schemas import AutoSchema
from rest_framework_swagger.renderers import OpenAPIRenderer, SwaggerUIRenderer,JSONRenderer
from rest_framework.decorators import api_view, renderer_classes,authentication_classes,permission_classes,detail_route
from rest_framework.permissions import BasePermission, IsAuthenticated, SAFE_METHODS
from rest_framework import response, schemas
from rest_framework import authentication

from quickstart.serializers import RestaurantsSerializer
from rest_framework import status
from rest_framework.decorators import api_view,APIView
from rest_framework.response import Response
from quickstart.serializers import *
from quickstart.models import Computer
from rest_framework import generics
from django.http import QueryDict

from rest_framework.filters import BaseFilterBackend
import coreapi

#@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])

#permission_classes = (permissions.AllowAny,)
#
# @api_view()
# @renderer_classes([OpenAPIRenderer, SwaggerUIRenderer])
# def schema_view(request):
#     generator = schemas.SchemaGenerator(title='Restaurant API')
#     return response.Response(generator.get_schema(request=request))

@api_view(['GET'])
def restaurant_list(request):
    if request.method == 'GET':
        restaurantCollection = models.Restaurant
        restaurantlist = []
        for s in restaurantCollection.find():
            restaurantlist.append(s)
        serializer = RestaurantsSerializer(restaurantlist, many=True)
        return JsonResponse(serializer.data, status=status.HTTP_201_CREATED, safe=False)

@api_view(['GET'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def get_county(request,format='json'):

    data={"result": "Success"}

    return JsonResponse(data, status=status.HTTP_200_OK)

@api_view(['GET'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def get_queryset(request):

    #queryset = ModelName.objects.all()
    name = request.GET['name']
    number = request.GET['no']
    if number:
        print("key")
    else:
        print("Not Key")
    print("Name==>"+str(name)+"number==>"+str(number))
    queryset = {"name":"Not Availble"}
    return JsonResponse(queryset, status=status.HTTP_200_OK)
@api_view(['POST'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def post_data(request):
    jsonData = str(request.data)
    print(jsonData)
    var=json.dumps(jsonData)
    print(var)
    dd=json.loads(var)
    if "range" in dd:
        print("range key")
    else:
        print("Not range Key")
    print(dd)
    # for record in example_records:
    #     print("record-->"+record)
    # return record
    #data=json.loads(var)
    print("data==>"+var)
    queryset = {"name": "Not Availble"}
    return JsonResponse(queryset, status=status.HTTP_200_OK)
@api_view(['GET'])
#@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
#@renderer_classes([SwaggerUIRenderer, OpenAPIRenderer])
def save_medical(request):
    print(request.GET['name'])
    #data=request.query_params
    #print(data)
   # print(request.GET['name'])
    data = {"name": "demo"}
    print(data)
    return Response(data, status=status.HTTP_200_OK,content_type='application/json')



#@renderer_classes([SwaggerUIRenderer, OpenAPIRenderer])
@api_view(['POST'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def save_medicaldata(request):
    jsonData = str(request.data)
    print(jsonData)
    var = json.dumps(jsonData)
    print(var)
    queryset = {"name": "demo"}
    return JsonResponse(queryset, status=status.HTTP_200_OK)
def permission_denied_handler(request):
    from django.http import HttpResponse
    return HttpResponse('you have no permissions!')

@api_view(['GET'])
#@detail_route(methods=['post'], url_path='set-password')

#@renderer_classes([OpenAPIRenderer])
#@authentication_classes((TokenAuthentication, SessionAuthentication))
#@permission_classes((AllowAny,))
def save_me(request):
    #my_header = request.headers.get('')
    #jsonData = str(request.data)
    #print(jsonData)
    #var = json.dumps(jsonData)
    #print(var)
    #name = request.GET['name']
    data = {"name": "demo"}
    return Response(data, status=status.HTTP_201_CREATED)
class UserViewSet(viewsets.ViewSet):
    """
    A simple ViewSet that for listing or retrieving users.
    """
    def post(self, request):
        queryset = User.objects.all()
        serializer = UserSerializer(queryset, many=True)
        return Response(serializer.data)
@api_view(['POST'])
def get_querysetR(request):
    username = request.DATA['username']
    password = request.DATA['password']
    data = {"name": "demo"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def test(request):
    pass
class MyView(generics.CreateAPIView):
    #print("hello")
    serializer_class = ComputerSerializer
    #print("hello 2")
    def post(self, request, *args, **kwargs):
        """
            Create a MyModel
            ---
            parameters:
                - name: file
                  description: file
                  required: True
                  type: file
            responseMessages:
                - code: 201
                  message: Created
        """
        #print("hello 3")
        print(str(request.data))
        #return self.create(request, *args, **kwargs)
        return Response("updated", status=status.HTTP_200_OK)



class MyViewRe(generics.CreateAPIView):
    serializer_class = ComputerSerializer
    #print("hello")
    #print(serializer_class)
    queryset = {"name": "demo"}
    def post(self, request, *args, **kwargs):
        """
            Create a MyModel
            ---
            parameters:
                - name: file
                  description: file
                  required: True
                  type: file
            responseMessages:
                - code: 201
                  message: Created
        """
        #Ob=ComputerSerializer.Object.all()
        #return self.create(request, *args, **kwargs)
        print("hello")
        print(request.data)
        queryset = {"name": "demo"}
        return JsonResponse(queryset, status=status.HTTP_200_OK)

class MyViewRew(generics.QuerySet):
    serializer_class = ComputerSerializer
    print("hello 1")
    def post(self, request, *args, **kwargs):
        print("hello")
        print(request.data)
        #return Response("updated", status=status.HTTP_200_OK)
        queryset = {"name": "demo"}
        return JsonResponse(queryset, status=status.HTTP_200_OK)

class myModelData(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        #print("hello 3")
        quer = {"result": "Model parameters added"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
#=======================================Execution API===============================


class runBatchExecution(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        print("hello 3")
        quer = {"result": "Model is invoked"}
        return JsonResponse(quer, status=status.HTTP_200_OK)


@api_view(['GET'])
def executionJobStatus(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"status": "completed"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def intruptJob(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "job execution stopped successfully"}
    return Response(data, status=status.HTTP_200_OK)


class runSingleExecution(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        print("hello 3")
        quer = {"result": "completed"}
        return JsonResponse(quer, status=status.HTTP_200_OK)





