from django.conf.urls import url

from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from execution import views,models
from django.http import JsonResponse
from execution.views import *
from execution.models import *


urlpatterns = [
    #path('quickstart/', views.SnippetList.as_view()),
    #path('quickstart/<int:pk>/', views.SnippetDetail.as_view()),
   # path('execution/',views.get_county),
    #url(r'^execution/getEmp/$', views.get_county),
    #url(r'^execution/getEmpDe/$', views.get_queryset),
    #url(r'^execution/getPostD', views.post_data),
    #url(r'^/add', views.myModelData.as_view()),
    url(r'^AIQ_Analytics/model/p2p/run/batch',runBatchExecution.as_view()),
    url(r'^AIQ_Analytics/model/p2p/run/status/?jobId=12', executionJobStatus),
    url(r'^AIQ_Analytics/model/p2p/run/interruptJob/?jobId=12', intruptJob),
    url(r'^AIQ_Analytics/model/p2p/run/single',runSingleExecution.as_view()),

]

urlpatterns = format_suffix_patterns(urlpatterns)