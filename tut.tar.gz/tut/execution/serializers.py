from django.contrib.auth.models import User, Group
from quickstart.models import *
from rest_framework import serializers


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ['url', 'username', 'email', 'groups']


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ['url', 'name']
class UniSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = University
        fields = ['id', 'name']

class RestaurantsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Restaurant
        fields = ('_id', 'name', 'rating')
class ComputerSerializer (serializers.ModelSerializer):
    class Meta:
        model = Computer
        fields='__all__'
class ModelDataSerializer_example(serializers.ModelSerializer):
    class Meta:
        model = Model_Added_Data
        fields='__all__'
class ModelDataSerializer_Job(serializers.ModelSerializer):
    class Meta:
        model = Model_Added_Data
        fields='jobId'
        read_only_fields = ('jobId',)
class ModelDataSerializerFeature(serializers.ModelSerializer):
    class Meta:
        model = Feature_Data
        fields='__all__'


