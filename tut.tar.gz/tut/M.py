from D import Cal
_t_= Cal().multiplyNums(4,4)
print(_t_)