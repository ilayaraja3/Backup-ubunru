from django.apps import AppConfig


class AdminapiConfig(AppConfig):
    name = 'adminapi'
