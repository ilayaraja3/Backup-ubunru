
class Cal():
    def multiplyNums(self,x, y):
        #        return x + y
        # create addNumbers static method
        Cal.multiplyNums = staticmethod(Cal.multiplyNums)

        # print('Product:', Calculator.multiplyNums(15, 110))

        return x + y
if __name__=="__main__":
    r=Cal()
    m=r.multiplyNums(1,3)
    print(m)