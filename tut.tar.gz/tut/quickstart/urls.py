from django.conf.urls import url
from rest_framework import routers
#from .views import UserViewSet
from .models import University
# router = routers.DefaultRouter()
# router.register(r'students', UserViewSet)
# router.register(r'universities', University)
#
# urlpatterns = router.urls

from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from quickstart import views
from django.http import JsonResponse

urlpatterns = [
    #path('quickstart/', views.SnippetList.as_view()),
    #path('quickstart/<int:pk>/', views.SnippetDetail.as_view()),
    path('quickstart/',views.get_county),
    url(r'^quickstart/getEmp/$', views.get_county),
    url(r'^quickstart/getEmpDe/$', views.get_queryset),
    url(r'^quickstart/getPostD', views.post_data),
]

urlpatterns = format_suffix_patterns(urlpatterns)