from django.conf.urls import url
from rest_framework import routers
from .views import UserViewSet
from .models import University
router = routers.DefaultRouter()
router.register(r'students', UserViewSet)
router.register(r'universities', University)

urlpatterns = router.urls