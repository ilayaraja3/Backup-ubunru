from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import time

class Reap():
    def urlgenerator(self,search_term, url, breaker='%20'):
            search_term = search_term
            boolsearch = (' ' in search_term) == True
            if boolsearch is False:
                url = url + search_term
            else:
                newsearchterm = search_term.replace(' ', breaker)
                url = url + newsearchterm
            return url
        
    def magic(self,word):
        url = "https://www.vocabulary.com/dictionary/"
        driverpath = '/home/aaum/chromedriver'
#         local machine path
#        driverpath = '/home/aaum/Documents/Hakuba/web-driver/linux/chromedriver'
        url = self.urlgenerator(word,url)
        print(url)
        print("#"*20)
        options = Options()
        options.add_argument("--headless")
        browser = webdriver.Chrome(chrome_options=options, executable_path=driverpath)
        browser.get(url)
        html = browser.page_source
        soup = BeautifulSoup(html, 'html.parser')
#         time.sleep(240)
        browser.quit()
        data = soup.find(class_="results").find_all("li")
        daf = pd.DataFrame([],columns = ['word','news','link','source','updated_datetime'])

        for i in data:
            try:
                date = i.find(class_="date").text
            except:
                date = None
            tdf = pd.DataFrame([word,i.div.text,i.a.get("href"),i.span.text,date])
        #     print(tdf)
            tdf = tdf.T
            tdf.columns = ['word','news','link','source','updated_datetime']

            daf = daf.append(tdf)
        daf = daf.dropna()
    
        return daf
    
    def main(self):
        #engine = create_engine('mysql+mysqlconnector://root:savio123@localhost/savio_app')
        engine = create_engine('mysql+mysqlconnector://root:aaum@localhost/savio_app')
        df1 = pd.read_sql('SELECT word FROM word_datasavio group by word limit 4',con = engine)
        print(len(df1.word.unique()))
        data = list(map(self.magic,df1.word.unique()))
        df = pd.DataFrame([],columns = ['word','news','link','source','updated_datetime'])
        
        for i in data:
            print("result===>"+i)
            df = df.append(i)
        df = df.reset_index(drop=True)
        df['word'] = df.word.str.encode('unicode_escape')
        df['news'] = df.news.str.encode('unicode_escape')
        df['link'] = df.link.str.encode('unicode_escape')
        df['source'] = df.source.str.encode('unicode_escape')
        df['updated_datetime'] = df.updated_datetime.str.encode('unicode_escape')
        
        print(df.shape)
        df.to_sql(name='newsexample', con=engine, if_exists = 'replace', index=False)
        print("pushed")
if __name__=="__main__":
    r=Reap()
    r.main()
        
        

