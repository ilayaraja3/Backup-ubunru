
from django.shortcuts import render

# Create your views here.
from django.contrib.auth.models import User, Group
from rest_framework import viewsets
from quickstart.serializers import UserSerializer, GroupSerializer,UniSerializer
from rest_framework.validators import ValidationError

from quickstart.models import University
from rest_framework.decorators import api_view
from rest_framework_swagger import renderers
from rest_framework.decorators import api_view, renderer_classes
from django.core.serializers import serialize
from .models import *
from rest_framework import status
from django.http import JsonResponse
from rest_framework import viewsets
import logging
import threading
import time
import os
from django.conf import settings
from django.http import HttpResponse, Http404
from rest_framework.response import Response
import json
from rest_framework.filters import BaseFilterBackend
import coreapi
from rest_framework.schemas import AutoSchema
from rest_framework_swagger.renderers import OpenAPIRenderer, SwaggerUIRenderer,JSONRenderer
from rest_framework.decorators import api_view, renderer_classes,authentication_classes,permission_classes,detail_route
from rest_framework.permissions import BasePermission, IsAuthenticated, SAFE_METHODS
from rest_framework import response, schemas
from rest_framework import authentication

from quickstart.serializers import RestaurantsSerializer
from rest_framework import status
from rest_framework.decorators import api_view,APIView
from rest_framework.response import Response
from quickstart.serializers import *
from quickstart.models import Computer
from rest_framework import generics
from django.http import QueryDict

from rest_framework.filters import BaseFilterBackend
import coreapi

#@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])

#permission_classes = (permissions.AllowAny,)
#
# @api_view()
# @renderer_classes([OpenAPIRenderer, SwaggerUIRenderer])
# def schema_view(request):
#     generator = schemas.SchemaGenerator(title='Restaurant API')
#     return response.Response(generator.get_schema(request=request))

@api_view(['GET'])
def restaurant_list(request):
    if request.method == 'GET':
        restaurantCollection = models.Restaurant
        restaurantlist = []
        for s in restaurantCollection.find():
            restaurantlist.append(s)
        serializer = RestaurantsSerializer(restaurantlist, many=True)
        return JsonResponse(serializer.data, status=status.HTTP_201_CREATED, safe=False)

@api_view(['GET'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def get_county(request,format='json'):

    data={"result": "Success"}

    return JsonResponse(data, status=status.HTTP_200_OK)

@api_view(['GET'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def get_queryset(request):

    #queryset = ModelName.objects.all()
    name = request.GET['name']
    number = request.GET['no']
    if number:
        print("key")
    else:
        print("Not Key")
    print("Name==>"+str(name)+"number==>"+str(number))
    queryset = {"name":"Not Availble"}
    return JsonResponse(queryset, status=status.HTTP_200_OK)
@api_view(['POST'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def post_data(request):
    jsonData = str(request.data)
    print(jsonData)
    var=json.dumps(jsonData)
    print(var)
    dd=json.loads(var)
    if "range" in dd:
        print("range key")
    else:
        print("Not range Key")
    print(dd)
    # for record in example_records:
    #     print("record-->"+record)
    # return record
    #data=json.loads(var)
    print("data==>"+var)
    queryset = {"name": "Not Availble"}
    return JsonResponse(queryset, status=status.HTTP_200_OK)
@api_view(['GET'])
#@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
#@renderer_classes([SwaggerUIRenderer, OpenAPIRenderer])
def save_medical(request):
    print(request.GET['name'])
    #data=request.query_params
    #print(data)
   # print(request.GET['name'])
    data = {"name": "demo"}
    print(data)
    return Response(data, status=status.HTTP_200_OK,content_type='application/json')



#@renderer_classes([SwaggerUIRenderer, OpenAPIRenderer])
@api_view(['POST'])
@renderer_classes([renderers.OpenAPIRenderer, renderers.SwaggerUIRenderer,renderers.JSONRenderer])
def save_medicaldata(request):
    jsonData = str(request.data)
    print(jsonData)
    var = json.dumps(jsonData)
    print(var)
    queryset = {"name": "demo"}
    return JsonResponse(queryset, status=status.HTTP_200_OK)
def permission_denied_handler(request):
    from django.http import HttpResponse
    return HttpResponse('you have no permissions!')

@api_view(['GET'])
#@detail_route(methods=['post'], url_path='set-password')

#@renderer_classes([OpenAPIRenderer])
#@authentication_classes((TokenAuthentication, SessionAuthentication))
#@permission_classes((AllowAny,))
def save_me(request):
    #my_header = request.headers.get('')
    #jsonData = str(request.data)
    #print(jsonData)
    #var = json.dumps(jsonData)
    #print(var)
    #name = request.GET['name']
    data = {"name": "demo"}
    return Response(data, status=status.HTTP_201_CREATED)
class UserViewSet(viewsets.ViewSet):
    """
    A simple ViewSet that for listing or retrieving users.
    """
    def post(self, request):
        queryset = User.objects.all()
        serializer = UserSerializer(queryset, many=True)
        return Response(serializer.data)
@api_view(['POST'])
def get_querysetR(request):
    username = request.DATA['username']
    password = request.DATA['password']
    data = {"name": "demo"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def test(request):
    pass
class MyView(generics.CreateAPIView):
    #print("hello")
    serializer_class = ComputerSerializer
    #print("hello 2")
    def post(self, request, *args, **kwargs):
        """
            Create a MyModel
            ---
            parameters:
                - name: file
                  description: file
                  required: True
                  type: file
            responseMessages:
                - code: 201
                  message: Created
        """
        #print("hello 3")
        print(str(request.data))
        #return self.create(request, *args, **kwargs)
        return Response("updated", status=status.HTTP_200_OK)



class MyViewRe(generics.CreateAPIView):
    serializer_class = ComputerSerializer
    #print("hello")
    #print(serializer_class)
    queryset = {"name": "demo"}
    def post(self, request, *args, **kwargs):
        """
            Create a MyModel
            ---
            parameters:
                - name: file
                  description: file
                  required: True
                  type: file
            responseMessages:
                - code: 201
                  message: Created
        """
        #Ob=ComputerSerializer.Object.all()
        #return self.create(request, *args, **kwargs)
        print("hello")
        print(request.data)
        queryset = {"name": "demo"}
        return JsonResponse(queryset, status=status.HTTP_200_OK)

class MyViewRew(generics.QuerySet):
    serializer_class = ComputerSerializer
    print("hello 1")
    def post(self, request, *args, **kwargs):
        print("hello")
        print(request.data)
        #return Response("updated", status=status.HTTP_200_OK)
        queryset = {"name": "demo"}
        return JsonResponse(queryset, status=status.HTTP_200_OK)
@api_view(['GET'])
def get_querysetR(generics):

    data = {"name": "demo"}
    return Response(data, status=status.HTTP_200_OK)
class MyViewQuery(generics.ListAPIView):
    print("hello")
    #serializer_class = ComputerSerializer
    print("hello 2")
    def get_queryset(self):
        if self.request.method == 'GET':
            state_name = self.request.GET.get('q', None)
            return state_name
@api_view(['GET'])
def get_querysetRList(request):
    username = request.DATA['name']

    data = {"name": username}
    return Response(data, status=status.HTTP_200_OK)

class myModelData(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        #print("hello 3")
        quer = {"result": "Model parameters added"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
class myModelDataUpdate(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        print("hello 3")
        quer = {"result": "Model parameters updated"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
class runModel(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        #print("hello 3")
        quer = {"jobId":123,"result": "Model is invoked"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
class modelStatus(generics.ListAPIView):
    #serializer_class = ModelDataSerializer_example
    get_serializer_class=ModelDataSerializer_Job
    def get_queryset(self):
        """
        Optionally restricts the returned purchases to a given user,
        by filtering against a `username` query parameter in the URL.
        """
        #queryset = Model_Added_Data.objects.all()
        print("==================Start===================")
        #print(self.kwargs['jobId'])
        #print(name = request.GET['jobId'])
        print("===================End==================")
        username = self.request.query_params.get('jobId', None)
        quer = {"status": "success"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
class modelDataSingle(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        #print("hello 3")
        quer = {"result": "Model parameters added"}
        return JsonResponse(quer, status=status.HTTP_200_OK)

@api_view(['GET'])
def getJobStatus(request,*args, **kwargs):
    print("==================Start 11111111===================")
    print(kwargs.keys())
    print("==================Start===================")
    jobId = request.GET['jobId']
    print(jobId)
    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"status": "success"}
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def getmodelList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"jobId": 12,"updatedtime": "2019-10-24","name": "model12","modelvalue": "Modeldata"},{"jobId": 13,"updatedtime": "2019-10-25","name": "model13","modelvalue": "Modeldata13"}]
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def getModelAction(request,*args, **kwargs):
    print("==================Start 11111111===================")
    print(kwargs.keys())
    print(args)
    print("==================Start===================")
    #jobId = request.GET['jobId']
    #print(jobId)
    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result":"Ingestion Started Successfully"}

    return Response(data, status=status.HTTP_200_OK)

class updateFeature(generics.CreateAPIView):
    serializer_class = ModelDataSerializerFeature
    def post(self, request, *args, **kwargs):
        #print("hello 3")
        quer = {"result": "Updated Successfully"}
        return Response(quer, status=status.HTTP_200_OK)


@api_view(['GET'])
def getIngestionstatusList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"ingestionId": 123343,"ingestionName": "oozijobs"},{"ingestionId":23432 ,"ingestionName": "oozijobs2"}]
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getDataSanity(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"id": "AD123","sanityName": "sanityNameList1"},{"id": "AD123","sanityName": "sanityNamelist3"},{"id": "AD124","sanityName": "sanityNameList4"},{"id": "AD126","sanityName": "sanityNamelist6"}]
    return Response(data, status=status.HTTP_200_OK)
#------------------------------------Admin---------------------------------------------
@api_view(['GET'])
def getparamList(request):
    #print("==================Start 11111111===================")

    #print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"paramName":"address","paramtype": "varchar"},{"paramName":"name","paramtype": "text"}]
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getOosiJobsList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"jobId": 123,"ooziname": "job1"},{"jobId": 124,"ooziname": "job2"}]
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def modelSchedule(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "Model execution scheduled successfully"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def availableModels(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"modelId": 1122,"modelName": "modelName1"},{"modelId": 1124,"modelName": "modelName2"}]
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getFeature(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result":"data"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getRulesList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"ruleId": 3443,"ruleName": "rule1"},{"ruleId": 3237,"ruleName": "rule2"}]
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def modelPurge(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "Data Removed Successfully"}
    return Response(data, status=status.HTTP_200_OK)

class customerAdd(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        #print("hello 3")
        quer = {"result": "Customer information added successfully"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
class customerUpdate(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        print("hello 3")
        quer = {"result": "Customer information updated successfully"}
        return JsonResponse(quer, status=status.HTTP_200_OK)
@api_view(['GET'])
def customerDelete(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "Customer information deleted successfully"}
    return Response(data, status=status.HTTP_200_OK)

#-----------------------Audit--------------------------------------
@api_view(['GET'])
def auditIngestionStatus(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "data"}
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def auditPredictionStatus(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "resultStatus"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def auditModelList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"modelId": 11,"auditModelName": "modelName5"},{"modelId": 1124,"auditModelName": "modelName2"}]
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def auditCustomerList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"customerId": 1,"customerName": "abc"},{"customerId": 2,"customerName": "xyz"}]
    return Response(data, status=status.HTTP_200_OK)

#----------------------------Execution API---------------------------------------------------

class runBatchExecution(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        print("hello 3")
        quer = {"result": "Model is invoked"}
        return JsonResponse(quer, status=status.HTTP_200_OK)


@api_view(['GET'])
def executionJobStatus(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"status": "completed"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def intruptJob(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "job execution stopped successfully"}
    return Response(data, status=status.HTTP_200_OK)


class runSingleExecution(generics.CreateAPIView):
    serializer_class = ModelDataSerializer_example
    def post(self, request, *args, **kwargs):
        print("hello 3")
        quer = {"result": "completed"}
        return JsonResponse(quer, status=status.HTTP_200_OK)




