from django.db import models

# Create your models here.
class University(models.Model):
    name = models.CharField(max_length=50)

    class Meta:
        verbose_name = "University"
        verbose_name_plural = "Universities"

    def __unicode__(self):
        return self.name
class Restaurant(models.Model):
    _id = models.TextField()
    name = models.TextField()
    rating = models.IntegerField()
class Computer(models.Model):
    model = models.CharField(max_length=255, null=True)
    serial_number = models.CharField(max_length=255, null=True)
    brand_name = models.CharField( max_length=255, null=True)
    number_of_usb_ports = models.IntegerField( null=True)
    hard_drive = models.IntegerField( null=True)
    ram = models.IntegerField( null=True)
    is_wifi_enabled = models.BooleanField( default=False)
    sound_system = models.CharField(max_length=255, null=True)
    cpu_speed = models.FloatField( null=True)
class Model_Added_Data(models.Model):
    name=models.TextField()
    modelvalue=models.TextField()
    updatedtime=models.TextField()
    jobId=models.IntegerField( null=True)

class Feature_Data(models.Model):
    name=models.TextField()
    modelvalue=models.TextField()
    #updatedtime=models.TextField()
    jobId=models.IntegerField( null=True)



