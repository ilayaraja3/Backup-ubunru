from django.conf.urls import url
from rest_framework import routers
from audit.views import *
#from .views import UserViewSet

# router = routers.DefaultRouter()
# router.register(r'students', UserViewSet)
# router.register(r'universities', University)
#
# urlpatterns = router.urls

from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from quickstart import views
from django.http import JsonResponse

urlpatterns = [
    #path('quickstart/', views.SnippetList.as_view()),
    #path('quickstart/<int:pk>/', views.SnippetDetail.as_view()),
    url(r'^AIQ_Analytics/model/p2p/ingestionStatus/list?type=ondemand&page=1&count=10',auditIngestionStatus),
    url(r'^AIQ_Analytics/model/p2p/audit/predictionStatus/list?page=1&count=10',auditPredictionStatus),
    url(r'^AIQ_Analytics/model/p2p/audit/models/list?page=1&count=10', auditModelList),
    url(r'^AIQ_Analytics/admin/audit/customers/list?page=1&count=10', auditCustomerList),
]

urlpatterns = format_suffix_patterns(urlpatterns)