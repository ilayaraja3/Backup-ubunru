from django.shortcuts import render

# Create your views here.

from django.shortcuts import render

# Create your views here.

from rest_framework import status
from rest_framework.decorators import api_view,APIView
from rest_framework.response import Response

@api_view(['GET'])
def auditIngestionStatus(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "data"}
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def auditPredictionStatus(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = {"result": "resultStatus"}
    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def auditModelList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"modelId": 11,"auditModelName": "modelName5"},{"modelId": 1124,"auditModelName": "modelName2"}]
    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def auditCustomerList(request):
    print("==================Start 11111111===================")

    print("==================Start===================")

    # print(name = request.GET['jobId'])
    print("===================End==================")
    # username = request.query_params.get('jobId', None)


    data = [{"customerId": 1,"customerName": "abc"},{"customerId": 2,"customerName": "xyz"}]
    return Response(data, status=status.HTTP_200_OK)

