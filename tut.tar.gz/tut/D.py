class Cal:
   def __init__(self, x=0, y=0):
       self.x = x
       self.y = y
   @staticmethod
   def multiplyNums(x, y):
      #Cal.multiplyNums = staticmethod(Cal.multiplyNums)
      a=int(x)
      b=int(y)
      return a + b
if __name__=="__main__":
    r=Cal()
    print(r.multiplyNums(2,3))