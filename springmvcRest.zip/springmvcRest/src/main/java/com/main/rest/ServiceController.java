package com.main.rest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class ServiceController {
	
	@RequestMapping(value = "/getData/{id}", method = RequestMethod.GET)
	public @ResponseBody String getEmployee(@PathVariable("id") int empId) {
		String id="10";
		return String.valueOf(empId);
	}
	
	@RequestMapping(value = "/getResult", method = RequestMethod.GET)
	public @ResponseBody String getResult() {
		String id="10";
		return id;
	}
	@RequestMapping("/hello")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller");
 
		ModelAndView mv = new ModelAndView("helloworld");
		mv.addObject("message", "");
		mv.addObject("name", name);
		return mv;
	}
}
