import pandas as pd
a=exec(open('/home/aaum/testScript.py').read())
#b=pd.DataFrame(a)
print(a)