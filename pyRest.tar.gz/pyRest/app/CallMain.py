import django
#django.setup()
from app.models import User
   # print("--------------------------------------")
   # for p in User.objects.raw('SELECT * FROM user'):
    #    print(p)
def main():
    print("-----------")
    for p in User.objects.raw('SELECT * FROM user'):
        print(p)
if __name__=='__main__':
    main()



