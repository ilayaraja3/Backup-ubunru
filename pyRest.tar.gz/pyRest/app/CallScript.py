from subprocess import Popen, PIPE
import sys
import subprocess
import app.testScript as df
import re

class CallScriptFile:
    def callScript(self):

        """p = Popen(["python", "testScript.py"], cwd="/home/aaum", stdout=PIPE, stderr=PIPE)
        out, err = p.communicate()
        output=out.decode('utf-8').rstrip()
        print("--------"+output)"""

        output = df.main()
        #print(output)
        return output


