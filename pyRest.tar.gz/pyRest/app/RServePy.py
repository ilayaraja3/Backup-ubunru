import pyRserve
conn = pyRserve.connect(host="localhost", port=6311)
s='3'
b='4'
wash_clothes = '1'
clean_dishes = '2'

#mystring ="""{0}+{1}"""

#print ('\"',mystring.format(wash_clothes, clean_dishes),'\"')
#c='\"',s+b,'\"'

vard='\"'+s+"+"+b+'\"'
ba = str('\'{0}+{1}\''.format(str(b),str(s)))
print(str(ba))
print(conn.eval('{0}+{1}'.format(int(b),int(s))))