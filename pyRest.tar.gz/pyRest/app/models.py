from django.db import models
from rest_framework import serializers
#from . import models

# Create your models here.
class University(models.Model):
    name=models.CharField(max_length=10)

    class Meta:
        verbose_name="word_datasavio"


    def __unicode__(self):
        return self.word

class Student(models.Model):
    age=models.IntegerField()
    name=models.CharField(max_length=40)

    class Meta:
        verbose_name="Student"
        verbose_name_plural="Students"
    def __unicode__(self):
        return "%d %s" %(self.age,self.name)
class Country(models.Model):
    name=models.CharField(max_length=500)

class User(models.Model):
    user_id=models.IntegerField()
    name=models.CharField(max_length=250)
    class Meta:
        verbose_name="userdata"

    def __unicode__(self):
        return User

class Recipe(models.Model):
    name = models.CharField(max_length=150)
    description = models.TextField()
    cooking_instructions = models.TextField()
    slug = models.SlugField()
    preparation_time = models.IntegerField(help_text='Preparation time in minutes')
    cooking_time = models.IntegerField(help_text='Cooking time in minutes')
    created = models.DateTimeField()
    modified = models.DateTimeField()

class word_datasavio(models.Model):
    word=models.CharField(max_length=20)

    class Meta:
       verbose_name="word_datasavio"

    def __unicode__(self):
        return "%s" % ','.join(self.word)

