import requests

import requests
from requests.auth import HTTPDigestAuth
import json
url = 'http://192.168.1.117:8084/app/getEmp/?name=pavan&format=json'

myResponse = requests.get(url,verify=True)
print (myResponse.content)
