from django.shortcuts import render
from rest_framework import viewsets
from werkzeug.wrappers import accept

from .models import  University,Student
from .serializers import UniversitySerializer,StudentSerializer

from app.serializers import *
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.core.serializers import serialize
from .models import *
from rest_framework import status
from django.http import JsonResponse
from rest_framework import viewsets
import logging
import threading
import time
import os
from django.conf import settings
from django.http import HttpResponse, Http404

from django.core.files.storage import FileSystemStorage
from django.http import FileResponse
import json
from app.CallScript import CallScriptFile

import requests
from . import serializers
# Create your views here.
class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.name
    serializer_class = StudentSerializer

class UniversityViewSet(viewsets.ModelViewSet):
    queryset = University.name;
    serializer_class = UniversitySerializer

@api_view(['GET'])
def get_county(request,format='json'):
    #longitude = self.request.query_params.get('longitude')

    name = request.GET['name']
    #time.sleep(3)
    data={"result": name}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getscript(request,format='json'):
    #longitude = self.request.query_params.get('longitude')

    #name = request.GET['name']
    #time.sleep(3)
    print("-----------------------------------")
    output=CallScriptFile.callScript("")


    print(type(output))
    data={"result": output}

    return Response(data, status=status.HTTP_200_OK)
@api_view(['GET'])
def getscriptdata(request,format='json'):
    import subprocess
    output = subprocess.check_output(["/home/aaum/testScript.py", "--", ])
    return HttpResponse(output, content_type='text/plain')

@api_view(['GET'])
def getData(request):
    useid = request.GET['user']
    print(useid)
    #user = User.objects.get(useid)
    student_list = User.objects.all()
    for student in student_list:

        print(student.user_id)
        print("--------------------------------------")
        for p in User.objects.raw('SELECT * FROM app_user order by id desc'):

            print("===>",p.user_id,p.name,"<--name-->",p.id)
    data={"student":student.user_id}


    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getDataResult(request):
    useid = request.GET['user']
    for p in User.objects.raw('SELECT * FROM app_user'):
        print("===>", p.user_id, p.name, "<--name-->", p.id)
    #print(useid)
    #user = User.objects.get(useid)
    articles = User.objects.get(id=useid)

    return Response(str(articles), status=status.HTTP_200_OK,content_type='application/json')

@api_view(['POST'])
def create_entry(request):
    print(request.data.get('user'))


    return Response({"data":"result"},safe=False, status=status.HTTP_200_OK,content_type='application/json')
@api_view(['POST'])
def createdata(request):

    datav=int(request.data.get('user'))
    print(datav)
    for e in User.objects.all():
        print("8888==>",e.id,"name-->",str(e.name))
    use=User.objects.values_list()
    #print(use.__dict__.items())
    print("==>",use)
    users_list = list(use)  # important: convert the QuerySet to a list object
    return JsonResponse(users_list, safe=False,status=status.HTTP_200_OK,content_type='application/json')


    #return Response({"data":"result"}, status=status.HTTP_200_OK,content_type='application/json')

@api_view(['GET'])
def recipe_list(request):
    word = request.GET['word']
    user = word_datasavio.objects.get(word)
    data = {"user": user.word}

    return JsonResponse(data)

@api_view(['GET','POST'])
def result(request):
    result=str(request.data.get("name"))
    #'''result = str(request.data.get("name"))'''
    print(result)
    jsonRes={"result":str(result)}
    return JsonResponse(jsonRes,safe=False,status=status.HTTP_200_OK,content_type='application/json')

@api_view(['POST'])
def simple_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        jsonRes={"result":str(uploaded_file_url)}
    return JsonResponse(jsonRes,safe=False,status=status.HTTP_200_OK,content_type='application/json')
@api_view(['GET'])
def download(request, path):
    file_path = os.path.join(settings.MEDIA_ROOT, path)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/split.sh")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404
@api_view(['GET'])
def download_line(request):
    fs = FileSystemStorage('/home/aaum/pyRest/media/')
    response=FileResponse(fs.open('split.sh', 'rb'), content_type='application/force-download')
    response['Content-Disposition'] = 'attachment; filename="split.sh"'
    return response
