from subprocess import Popen, PIPE
import re
import subprocess

# ...

"""p = Popen(["python", "testScript.py"], cwd="/home/aaum", stdout=PIPE, stderr=PIPE)
out, err = p.communicate()
print(out
import sys
import subprocess
s2_out = subprocess.check_output([sys.executable, "/home/aaum/testScript.py", "34"])
print(s2_out)"""
import pandas as pd
def main():
   #a=pd.read_csv("/home/aaum/Downloads/test1.csv")
   a = pd.read_csv("/build/test_new.csv")
   #/build/test_new.csv
   print(a)
   return a
if __name__=="__main__":
    main()