from rest_framework import serializers
from .models import Student,University,Country,Recipe,User
from rest_framework import serializers
from . import models
class UniversitySerializer(serializers.ModelSerializer):
    class Meta:
        model=University

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model=Student

class CountrySerializer(serializers.Serializer):
    name = serializers.CharField(max_length=250)

    def create(self, validated_data):
        country_obj = Country(**validated_data)
        country_obj.save()
        return country_obj

    def update(self, instance, validated_data):
        instance.name = validated_data["name"]
        instance.save()
        return instance
class IngredientSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Recipe
        fields = ('name', 'amount', 'measurement')

class RecipeSerializer(serializers.ModelSerializer):
    ingredients = IngredientSerializer(many=True, read_only=True)
    class Meta:
        model = models.Recipe
        fields = ('slug', 'name', 'description', 'cooking_instructions',
            'cooking_time', 'preparation_time',
            'created', 'modified')

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'user_id')
