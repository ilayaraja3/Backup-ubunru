import pandas as pd
a=pd.read_csv("/home/aaum/Downloads/test1.csv")
print(a)