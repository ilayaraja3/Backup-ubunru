import pyodbc

class PyDemo:
    def myfu(self):
        print(pyodbc.drivers())
        cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost;DATABASE=test;Trusted_Connection=yes;')
        cursor = cnxn.cursor()
        cursor.execute("SELECT * from test.dbo.app_user;")
        row = cursor.fetchone()
        while row:
            print(row)
            row = cursor.fetchone()
        cursor.close()
        return row

    if __name__ == "__main__":
        myfu()

d=PyDemo()
d.myfu()

