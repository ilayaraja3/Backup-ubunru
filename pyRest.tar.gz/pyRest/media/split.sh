fileName=$1
start=$2
stop=$3
newFile=$4
ffmpeg -i $fileName -acodec copy -ss $start -to $stop $newFile.wav -y
#echo $start
#echo $stop

