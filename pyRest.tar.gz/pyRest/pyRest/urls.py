"""pyRest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls import url, include
from app.views import StudentSerializer,UniversitySerializer
from app import views
from django.http import JsonResponse

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^app/getUni/$', views.UniversityViewSet),
    url(r'^app/getStu/$', views.StudentViewSet),
    url(r'^app/getEmp/$', views.get_county),
    url(r'^app/getScript/$', views.getscript),
    url(r'^app/getScriptData/$', views.getscriptdata),
    url(r'^app/getData/$', views.getData),
    url(r'^app/getDataResult/$', views.getDataResult),
    url(r'^app/getDataPost/$', views.create_entry),
    url(r'^app/getDataPostData/$', views.createdata),
    url(r'^app/getResult/$',views.result),
    url(r'^app/recipes', views.recipe_list),
    url(r'^app/uploads', views.simple_upload),
    url(r'^app/downloads', views.download),
    url(r'^app/download', views.download_line),
]
