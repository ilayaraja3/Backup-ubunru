import os

from django.conf import settings


# file_path = os.path.join(settings.MEDIA_ROOT,"media")
print(settings.MEDIA_ROOT)