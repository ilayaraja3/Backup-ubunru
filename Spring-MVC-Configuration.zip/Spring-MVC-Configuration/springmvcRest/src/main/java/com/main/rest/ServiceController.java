package com.main.rest;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.main.rest.user.dao.UserDAO;
import com.main.rest.user.model.MediaTypeUtils;
import com.main.rest.user.model.User;
@Controller
public class ServiceController {

    @Autowired
    private ServletContext servletContext;
	
	@RequestMapping(value = "/getData/{id}", method = RequestMethod.GET)
	public @ResponseBody String getEmployee(@PathVariable("id") int empId) {
		String id="10";
		return String.valueOf(empId);
	}
	
	@RequestMapping(value = "/getResult", method = RequestMethod.GET)
	public @ResponseBody User getResult() {
		String id="10";
		User us =new User();
		us.setUsername("ilayaraja");
		us.setPassword("Password@123");
		us.setAddress("Chennai");
		return us;
	}
	
	@RequestMapping(value = "/getResultData", method = RequestMethod.GET)
	public @ResponseBody User getResultData(@RequestBody User usD) {
		String id="10";
		System.out.println("result-->"+usD.getUsername());
		User us =new User();
		us.setUsername("ilayaraja");
		us.setPassword("Password@123");
		us.setAddress("Chennai");
		return usD;
	}
	@RequestMapping("/hello")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller");
 
		ModelAndView mv = new ModelAndView("helloworld");
		mv.addObject("message", "");
		mv.addObject("name", name);
		return mv;
	}
	
	@RequestMapping(value="/savefileData",method=RequestMethod.POST)  
	public ModelAndView upload(@RequestParam CommonsMultipartFile file,HttpSession session) throws IOException{  
	        //String path=session.getServletContext().getRealPath("/");  
	        String filename=file.getOriginalFilename();  
	          String path="/home/aaum/Desktop/files";
	          
	          String filePath = "/home/aaum/Desktop/files";
	  		Process proc1 = Runtime.getRuntime().exec("chmod 777" + filePath);
	  		try {
				// dao.createFolderIfNotExists("/home/aaum/Desktop/");
				UserDAO.createFolderIfNotExists("/home/aaum/Desktop/files");
			} catch (SecurityException se) {
			}
	        System.out.println(path+" "+filename);  
	        byte[] bytes = file.getBytes();  
	        BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(path + File.separator + filename)));  
	        stream.write(bytes);  
	        stream.flush();  
	        stream.close(); 
	        Process proc2 = Runtime.getRuntime().exec("chmod 777" + path+"/"+filename);
	       // UserDAO.saveToFile(uploadedInputStream, path+"/"+filename);
	         
	          
	        return new ModelAndView("index","filename",path+"/"+filename);  
	    }
	
	@RequestMapping(value="/savefileDemo",method=RequestMethod.POST)   
	 public ModelAndView fileUploaded(@RequestParam MultipartFile file) throws IOException {    
	  InputStream inputStream = null;    
	  OutputStream outputStream = null;    
	    
	//  MultipartFile file = uploadedFile.getFile();    
	    
	  String fileName = file.getOriginalFilename();
	  String filePath="";
	    final String fileLocations="/var/lib/tomcat7/webapps/uploads/git_repository";
	  String filename=file.getOriginalFilename(); 
	  System.out.println("FileName==>"+fileName);
	 try {
			// dao.createFolderIfNotExists("/home/aaum/Desktop/");
			UserDAO.createFolderIfNotExists(fileLocations);
		} catch (SecurityException se) {
			System.out.println("Erro==>"+se.getMessage());
		}
	  try {    
	   inputStream = file.getInputStream();    
	    
	   File newFile = new File(fileLocations+"/"+ fileName);    
	    filePath=fileLocations+"/" + fileName;
	   Process proc1 = Runtime.getRuntime().exec("chmod 777" + fileLocations+"/" + fileName);
	   /*if (!newFile.exists()) {    
	    newFile.createNewFile();    
	   }*/    
	   outputStream = new FileOutputStream(newFile);    
	   int read = 0;    
	   byte[] bytes = new byte[1024];    
	    
	   while ((read = inputStream.read(bytes)) != -1) {    
	    outputStream.write(bytes, 0, read);    
	   }    
	  } catch (IOException e) {    
	   // TODO Auto-generated catch block    
	   e.printStackTrace();    
	  }    
	    
	  return new ModelAndView("index", "filename", filePath);    
	 }    
	
	 @RequestMapping("/download1")
	    public ResponseEntity<InputStreamResource> downloadFile1(@RequestParam(defaultValue = "file") String fileName) throws IOException {
	 
	        MediaType mediaType = MediaTypeUtils.getMediaTypeForFileName(this.servletContext, fileName);
	        System.out.println("fileName: " + fileName);
	        System.out.println("mediaType: " + mediaType);
	        String Directorty="/home/aaum/Desktop/files";
	        File file = new File(Directorty + "/" + fileName);
	        System.out.println(Directorty + "/" + fileName);
	        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
	 
	        return ResponseEntity.ok()
	                // Content-Disposition
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
	                // Content-Type
	                .contentType(mediaType)
	                // Contet-Length
	                .contentLength(file.length()) //
	                .body(resource);
	    }
	 
	 @RequestMapping("/download2")
	    public ResponseEntity download2(@RequestParam(defaultValue = "file") String fileName) throws IOException {
		 ResponseEntity<InputStreamResource> downloadFile1=downloadFile1(fileName);
	      
	 System.out.println("downloading");
	        return downloadFile1;
	    }
	 
	 @RequestMapping(value="/savefile",method=RequestMethod.POST)   
	 public ModelAndView fileUpload(@RequestParam MultipartFile file) throws IOException {    
	    
	  String fileName = file.getOriginalFilename();
	    final String fileLocations="/home/aaum/Desktop/files";
	  String filename=file.getOriginalFilename(); 
	  System.out.println("FileName==>"+fileName);
	 try {
			// dao.createFolderIfNotExists("/home/aaum/Desktop/");
			UserDAO.createFolderIfNotExists(fileLocations);
		} catch (SecurityException se) {
			System.out.println("Erro==>"+se.getMessage());
		}
	 	UserDAO.save(file.getInputStream(), fileLocations, filename);
	  
	    
	  return new ModelAndView("index", "filename", filename +" File Saved Successfully");    
	 }    
}
