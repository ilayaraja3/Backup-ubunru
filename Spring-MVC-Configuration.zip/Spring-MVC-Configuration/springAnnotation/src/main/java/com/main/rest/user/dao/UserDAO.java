package com.main.rest.user.dao;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class UserDAO {
	
	public static void saveToFile(InputStream inStream, String target) throws IOException {
		OutputStream out = null;
		try {

			int read = 0;
			byte[] bytes = new byte[1024];
			out = new FileOutputStream(new File(target));
			while ((read = inStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			System.out.println("RadioDAO Error-->" + e.getMessage());
		} finally {
			try {
				out.flush();
				out.close();
			} catch (Exception e) {
				System.out.println("File DAO Output Stream Error Cause-->" + e.getMessage());
			}
			try {

				inStream.close();
			} catch (Exception e) {
				System.out.println("File DAO Input Stream Error Cause-->" + e.getMessage());
			}
		}
		// Process proc0 = Runtime.getRuntime().exec("chmod 777"+ file1 );
	}
	public static void save(InputStream inputStream,String fileLocations,String fileName) {
		
		OutputStream outputStream = null; 
		System.out.println("Uploading File");
		try {    
			   //inputStream = file.getInputStream();    
			    
			   File newFile = new File(fileLocations+"/"+ fileName);    
			   if (!newFile.exists()) {    
				   Process proc1 = Runtime.getRuntime().exec("chmod 777" + fileLocations+"/" + fileName);
			    newFile.createNewFile();    
			   }  
			   outputStream = new FileOutputStream(newFile);    
			   int read = 0;    
			   byte[] bytes = new byte[1024];    
			    
			   while ((read = inputStream.read(bytes)) != -1) {    
			    outputStream.write(bytes, 0, read);    
			   }    
			  } catch (IOException e) {    
				  System.out.println("Error fileUpload==>"+e.getMessage());
			   // TODO Auto-generated catch block    
			   e.printStackTrace();    
			  }    
	}
	public static void createFolderIfNotExists(String dirName) throws SecurityException, IOException {
		File theDir = new File(dirName);
		Process proc1 = null;
		try {
			String filepath = dirName + "/".toString();
			proc1 = Runtime.getRuntime().exec("chmod 777" + filepath);
			if (!theDir.exists()) {
				theDir.mkdir();
			}
		} catch (Exception e) {

		} finally {
			try {
				proc1.destroy();
			} catch (Exception e) {

			}
		}
	}

	public static void createFolderIfNotExistsForUser(String dirName, String username)
			throws SecurityException, IOException {
		File theDir = new File(dirName + "/" + username);
		String filePath = dirName + "/" + username;
		Process proc1 = Runtime.getRuntime().exec("chmod 777" + filePath);

		/*
		 * String filePath="/var/lib/tomcat7/webapps/mini/userUploads/"+id ;
		 * 
		 * String filePathToSave="/var/lib/tomcat7/webapps/mini/userUploads/"+id+'/'
		 * +fileDetail.getFileName();
		 * 
		 * Process proc1 = Runtime.getRuntime().exec("chmod 777"+ filePath );
		 */
		// Process proc1 = Runtime.getRuntime().exec("chmod 777"+ filePath );
		// //////System.out.println("DirectoryName");
		if (!theDir.exists()) {
			theDir.mkdir();
			Process proc0 = Runtime.getRuntime().exec("chmod 777" + filePath);
		}
	}
	
	// Using Java IO
	 public static void saveFileFromUrlWithJavaIO(String fileName, String fileUrl)
	 throws MalformedURLException, IOException {
	 BufferedInputStream in = null;
	 FileOutputStream fout = null;
	 try {
	 in = new BufferedInputStream(new URL(fileUrl).openStream());
	 fout = new FileOutputStream(fileName);

	byte data[] = new byte[1024];
	 int count;
	 while ((count = in.read(data, 0, 1024)) != -1) {
	 fout.write(data, 0, count);
	 }
	 } finally {
	 if (in != null)
	 in.close();
	 if (fout != null)
	 fout.close();
	 }
	 }


}
