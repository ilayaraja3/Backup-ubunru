-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: manboat_admin
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `module_execution`
--

DROP TABLE IF EXISTS `module_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_execution` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowname` varchar(45) DEFAULT NULL,
  `updatedate` varchar(45) DEFAULT NULL,
  `updatetime` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_execution`
--

LOCK TABLES `module_execution` WRITE;
/*!40000 ALTER TABLE `module_execution` DISABLE KEYS */;
INSERT INTO `module_execution` VALUES (1,'assessInquiry','2018-05-10','09:08:07'),(2,'scoreApplicant','2018-01-01','10:00:03'),(3,'optimizeGrant','2018-01-01','10:00:03'),(4,'admitToEnroll','2018-01-01','10:00:03'),(5,'maximizeRetention','2018-01-01','10:00:03'),(6,'LTV','2018-01-01','10:00:03');
/*!40000 ALTER TABLE `module_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registration` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `campus` varchar(45) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zipCode` varchar(45) DEFAULT NULL,
  `contactNo` varchar(20) DEFAULT NULL,
  `emailId` varchar(100) DEFAULT NULL,
  `userName` varchar(100) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `academicYear` varchar(10) DEFAULT NULL,
  `registeredDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(10) DEFAULT NULL,
  `usertype` varchar(45) DEFAULT NULL,
  `fileName` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration`
--

LOCK TABLES `registration` WRITE;
/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` VALUES (15,'aaumdbsample','Updated Value',NULL,'Chennai, Chennai, Chennai, 600012',NULL,NULL,NULL,'8015742378','Ilayaraja.Narasimman@aaumanayltics.com','aaumdbsample','password',NULL,'2017-12-05 10:18:47','active','vp',NULL),(16,'aaumdbsample','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilayaraja.narasimman@aaumanayltics.com','aaumdbsample','password',NULL,'2017-12-05 10:18:47','active','vp',NULL),(17,'aaumdbsample','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','aaumdbsample','password',NULL,'2017-12-05 10:18:47','active','vp',NULL),(18,'aaumdbs','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca','password',NULL,'2017-12-05 10:18:47','active','vp',NULL),(19,'ilayaraja','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','ilayarajan','password','2017','2017-12-05 10:18:47','active','vp',NULL),(20,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cs','password','2017','2017-12-05 10:18:47','active','vp',NULL),(21,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cs','password','2017','2017-12-05 10:18:47','active','vp',NULL),(22,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cs','password','2017','2017-12-05 10:18:47','active','vp',NULL),(23,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cs','password','2017','2017-12-05 10:18:47','active','vp',NULL),(24,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cs','password','2017','2017-12-05 10:18:47','active','vp',NULL),(25,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_css','password','2017','2017-12-05 10:18:47','active','vp',NULL),(26,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_css','password','2017','2017-12-05 10:18:47','active','vp',NULL),(27,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_css','password','2017','2017-12-05 10:18:47','active','vp',NULL),(28,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cssd','password','2017','2017-12-05 10:18:47','active','vp',NULL),(29,'as','Updated Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_csw','password','2017','2017-12-05 10:18:47','active','vp',NULL),(30,'asw','Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_csws','password','2017','2017-12-05 10:18:47','active','vp',NULL),(31,'asw','Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','Bhuvaneshwari.Rajendran@aaumanalytics.com','bca_cswsS','password','2017','2017-12-05 10:18:47','active','vp',NULL),(32,'asw','Value',NULL,'guindy, Chennai, tamilnadu, 600012',NULL,NULL,NULL,'8015742378','ilaybca@gmail.com','bca_cswsS','password','2017','2017-12-05 10:18:47','active','vp',NULL),(33,'asm','TN',NULL,'guindy','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcm','password','2017','2017-12-05 10:18:47','active','vp',NULL),(34,'asms','TN',NULL,'guindy','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmse','password','2017','2017-12-05 10:18:47','active','vp',NULL),(35,'asmser','TN',NULL,'guindy','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-05 10:18:47','active','vp',NULL),(36,'asmser','TN',NULL,'guindy','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-05 10:18:47','active','vp',NULL),(37,'asmser','TN','Chennai','guindy','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-06 06:49:08','approved','vp',NULL),(38,'asmseraw','TN','Chennai1','guindyw','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-06 06:49:03','approved','vp',NULL),(39,'asmseraw','TN','Chennai1','guindyw','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-06 06:49:03','approved','vp',NULL),(40,'asmseraw','TN','Chennai1','guindyw','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-06 06:49:03','approved','dean',NULL),(41,'bhuvana','TN','Chennai12','tidlepark','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bhuvaneshwari','password','2017','2017-12-06 06:49:03','approved','dean',NULL),(43,'bhuvana3','TN','Chennai12','tidlepark','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bhuvaneshwari1','password','2017','2017-12-06 06:52:51','approved','dean',NULL),(44,'ilayaraja1','TN','Chennai12','tidlepark','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','ilayaraja1','password','2017','2017-12-06 07:06:18','approved','dean',NULL),(45,'ilayaraja1','TN','Chennai12','tidlepark','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','ilayaraja123','password','2017','2017-12-14 05:34:54','approved','dean',NULL),(46,'ilayaraja12','TN','Chennai12','tidlepark','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','ilayaraja12','password','2017','2017-12-14 06:52:09','approved','dean','C:UsersLikesh IlayarajaDesktopManBoatFilesfrombhuvana1Datastudent_interests.csv'),(47,'ilayaraja3','TN','Chennai12','tidlepark','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','ilayaraja3','password','2017','2017-12-14 05:35:02','approved','dean',NULL),(48,'asmseraw','TN','Chennai1','guindyw','Chennai','tamilnadu','600012','8015742378','ilaybca@gmail.com','bcmser','password','2017','2017-12-14 05:36:30','pending','vp',NULL);
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `goalSetting` varchar(5) DEFAULT NULL,
  `dataPreparation` varchar(5) DEFAULT NULL,
  `rmAccessInquiry` varchar(5) DEFAULT NULL,
  `scoreApplicant` varchar(5) DEFAULT NULL,
  `rmOptimizeGrant` varchar(5) DEFAULT NULL,
  `rmAdmitToEnroll` varchar(5) DEFAULT NULL,
  `rmMaximizeGrant` varchar(5) DEFAULT NULL,
  `rmLTV` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'vp','vp','false','true','false','true','true','false','true'),(2,'vp','true','true','false','false','false','false','false','false'),(3,'dean','true','true','false','false','false','false','false','false');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `universityadmin`
--

DROP TABLE IF EXISTS `universityadmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `universityadmin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userName` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `administratorName` varchar(45) DEFAULT NULL,
  `universityName` varchar(100) DEFAULT NULL,
  `campusName` varchar(45) DEFAULT NULL,
  `campusLocation` varchar(100) DEFAULT NULL,
  `phoneNo` varchar(15) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `zipCode` varchar(45) DEFAULT NULL,
  `databaseName` varchar(45) DEFAULT NULL,
  `logoName` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `academicYear` varchar(45) DEFAULT NULL,
  `universityId` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `universityadmin`
--

LOCK TABLES `universityadmin` WRITE;
/*!40000 ALTER TABLE `universityadmin` DISABLE KEYS */;
INSERT INTO `universityadmin` VALUES (1,'admin','Test@123','test User','user University','user Campus','user Location',NULL,'user@gmail.com','11223','12457_admin',NULL,'TN','2018-2019','userU2018-20191'),(2,'Demo','Demo@123','Demo Admin','Demo University','Demo Campus','Demo Location',NULL,'demo@gmail.com','55123',NULL,NULL,'TN','2018-2019',NULL);
/*!40000 ALTER TABLE `universityadmin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-01 15:19:46
